jQuery(document).ready(function($) {
    $('#slider').ganethraSlider();
    });
